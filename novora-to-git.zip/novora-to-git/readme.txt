Hello everyone.

Here is an web application to extract lat-long of given address with the help of Google map API.
Web Programming launguages and technologies are used as given below:

Frontend: HTML5, CSS3, Javascript and Bootstrap Framework.
Backend: PHP and Mysql database.

Note: Please create and use your own Google MAP API key for proper working of code.
Google Map API Key will be needed in footer.php file at place of Your_Google_map_API_Key.


Need to do:

1.) Please create database in you localhost/live server
2.) Import the tables provided in file novoragroup.sql
3.) Keep and extract files of zip folder in your local/live host server
4.) navigate in your url and call index.php first.

Steps of Operation & Unit Testing:

1.) Firstly enter any address in input field of form given on index.php page and select Google Map or Open Street Map (I Apologize for this, SMO is not working, so please select Google Map only in dropdown) from drop down section.
2.) Submit the form. Once it is submitted it will redirect to index page again by submitting captured data.
3.) During the capturing and transaction of data it will get stored in mysql db-table.
4.) Once the data is submitted, all coordinated along with address and map used will be listed on index page itself.
5.) Once it is listed on index page, one can manage these data with the CRUD functionalities provided like edit and delete including  add also.
6.) Termination of the steps.

Thanks.

